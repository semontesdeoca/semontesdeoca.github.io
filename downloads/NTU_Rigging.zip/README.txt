SUPPORT FROM MAYA 2014+

Installation: Drag and drop install.mel file into a Maya Viewport
	
The compilation of scripts provided here are open source. Read LICENCE.txt for more details
Please feel free to join us if you wish to contribute to the open studio cooperative (studio.coop).
Our main repository is hosted at github (https://github.com/studiocoop/maya).