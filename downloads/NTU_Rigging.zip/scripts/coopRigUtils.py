import maya.mel as mel
import maya.cmds as cmds
import coopLib as lib

def segmentJoint():
    """
       Segments the selected joint evenly
       Tool created as an example for students to understand how scripting can ease tedious tasks 
       Please leave all comments, as they serve for beginner students to understand what is happening
    """
    # get start and end joint
    selection = cmds.ls(selection=True) # get selection
    print selection # just checking if the selection is right (should print the selected joint)
    startJoint = selection
    endJoint = cmds.pickWalk(d='down')

    # find position of start and end joints
    startPos = cmds.joint(startJoint, p=True, q=True) # query the absolute position
    endPos = cmds.joint(endJoint, p=True, q=True) # query the absolute position
    print "The start point is at: {0} | The end point is at: {1}".format(startPos, endPos)

    # how many segments? Ask the user for feedback
    result = cmds.promptDialog(title='Create joint chain', message='Nr of segments:',
        style="integer", button=['OK'], defaultButton='OK', dismissString='Cancel', tx=3)
    print result # checking if they entered data
    if result == 'OK':
        # save what the user entered
        segments = int(cmds.promptDialog(query=True, text=True))
    else:
        cmds.error("The user has not inserted any value")
    print "The chain will contain {0} segments".format(segments)

    # find segment distance (split total distance between the segments)
    # We will save the distance between the start and end joint as a list [X, Y, Z]
    # The brackets [] are used to define a list
    # The comma ' , ' separates the different list elements
    distance = [endPos[0] - startPos[0], endPos[1] - startPos[1], endPos[2] - startPos[2]]
    # The distance can also be checked with the distance measure tool
    # We also divide the distance by the number of segments and save the segment distance
    segmentDistance = [distance[0]/segments, distance[1]/segments, distance[2]/segments]
    print segmentDistance # checking the segment distance

    # create joint segments
    jName = "spine" # here you define the name of the new joints
    cmds.select(startJoint, r=True) # select starting joint
    for segment in range(1,int(segments)):
        print segment # this will print the segment number, starting from 1
        # get position of new joint to form segment
        jointPosX = startPos[0] + (segment * segmentDistance[0])
        jointPosY = startPos[1] + (segment * segmentDistance[1])
        jointPosZ = startPos[2] + (segment * segmentDistance[2])
        currentJoint = cmds.joint(n="{0}{1}".format(jName, segment), p=(jointPosX, jointPosY, jointPosZ) )
    #parent the last joint segment
    cmds.parent( endJoint, currentJoint)
    print "Joint chain created successfully"



def cleanup():
    """
        Freeze transforms and delete history
    """
    cmds.delete(ch=True) # delete history
    cmds.makeIdentity(apply=True, t=True, r=True, s=True, n=False, pn=True) # freeze transform (Maya default)



def selectJointHierarchy():
    """
        Selects only joints inside of the hierarchy of selected object
    """
    cmds.select(hierarchy=True)
    joints = cmds.ls(sl=True, typ='joint')
    if joints:
        cmds.select(joints, r=True)
        print cmds.ls(sl=True)
    else:
        cmds.error("No joints found in hierarchy")



def parentShape2Joint():
    """
        Parent a shape node to a joint transform
    """
    objects = cmds.ls(sl=True)
    if len(objects) == 2:
        shape = cmds.ls(objects[0], o=True, dag=True, s=True)
        if shape:
            cmds.select([shape[0], objects[1]], r=True)
            cmds.parent(s=True, r=True)
        else:
            cmds.error("No nurbs shape was selected")
    else:
        cmds.error("Nothing selected... Select shape first, then joint to parent to")



def transferConnections(source, destination, values=False):
    """ 
        Transfers connections from one node to another
        :params source: Name of source object
        :params destination: Name of destination object
        :params values: Boolean if values are to also be copied [False] 
    """
    cmds.copyAttr(str(source), str(destination), ic=True, oc=True, v=values)

    
    
def pointOnPolyConstraint():
    """ 
        Creates a pointOnPolyConstraint on selected objects 
    """
    constraint = cmds.pointOnPolyConstraint()[0]
    setPointOnPolyConstraint(constraint)
    return [constraint]#to match usual constraint return



def setPointOnPolyConstraint(constraint):
    """ 
        Fixes issue while setting pointOnPolyConstraints in referenced files
        :param constraint: Name of the created pointOnPolyConstraint
    """    
    sel = om.MSelectionList()
    
    om.MGlobal.getActiveSelectionList( sel )
    if sel.length() > 1:
        for i in range( 0, sel.length()-1 ):
            path = om.MDagPath()
            comp = om.MObject()
            sel.getDagPath( i, path, comp )
            strings = []
            sel.getSelectionStrings( i, strings )
            
            try:
                
                name = strings[0].split( '.' )[0]
                
                #also check for namespaces
                namespaceCheck = name.split(':')
                
                if len(namespaceCheck)>1:
                    name = namespaceCheck[len(namespaceCheck)-1]
                
                print name
                        
                if '.vtx[' in strings[0]:
                    meshIt = om.MItMeshVertex( path, comp )
                    if meshIt.count() == 1:
                        # single vertex selected - place on the vertex
                        uv = om.MScriptUtil()
                        uv.createFromDouble( 0.0 )
                        uvPtr = uv.asFloat2Ptr()
                        meshIt.getUV( uvPtr )
                        uv = [ om.MScriptUtil.getFloat2ArrayItem(uvPtr,0,j) for j in [0,1] ]
                        cmds.setAttr("{0}.{1}U{2}".format(constraint, name, i), uv[0])
                        cmds.setAttr("{0}.{1}V{2}".format(constraint, name, i), uv[1]) 
                elif '.e[' in strings[0]:
                    meshIt = om.MItMeshEdge( path, comp )
                    if meshIt.count() == 1:
                        # single edge selected - place in the center of the edge
                        vtx = [ meshIt.index( j ) for j in [ 0, 1 ] ]
                        vtxIt = om.MItMeshVertex( path )
                        uvs = []
                        for v in vtx:
                            prev = om.MScriptUtil()
                            prev.createFromInt( 0 )
                            prevPtr = prev.asIntPtr()
                            vtxIt.setIndex( v, prevPtr )
                            uv = om.MScriptUtil()
                            uv.createFromDouble( 0.0 )
                            uvPtr = uv.asFloat2Ptr()
                            vtxIt.getUV( uvPtr )
                            uvs.append( [ om.MScriptUtil.getFloat2ArrayItem(uvPtr,0,j) for j in [0,1] ] )
                        uv = [ 0.5*(uvs[0][j]+uvs[1][j]) for j in [0,1] ]
                        cmds.setAttr("{0}.{1}U{2}".format(constraint, name, i), uv[0], f=True)
                        cmds.setAttr("{0}.{1}V{2}".format(constraint, name, i), uv[1], f=True)
                elif '.f[' in strings[0]:
                    meshIt = om.MItMeshPolygon( path, comp )
                    if meshIt.count() == 1 and meshIt.hasUVs():
                        # single face selected - place in the center of the face
                        u, v = om.MFloatArray(), om.MFloatArray()
                        meshIt.getUVs( u, v )
                        uv = ( sum(u)/len(u), sum(v)/len(v) )
                        cmds.setAttr("{0}.{1}U{2}".format(constraint, name, i), uv[0])
                        cmds.setAttr("{0}.{1}V{2}".format(constraint, name, i), uv[1])
            except Exception:
                pass


  
def getSortedAxis(obj):
    """ 
        Returns the axis sorted by value
        :param obj: Object to be evaluated
        :return: ['x', 'y', 'z'] but in order from max[0] to min[2]
    """ 
    translation = cmds.getAttr('{0}.t'.format(obj))[0]
    
    if abs(translation[0])>=abs(translation[1]):
        if abs(translation[1])>=abs(translation[2]):
            axis = ['x', 'y', 'z']
        else:
            if abs(translation[0])>=abs(translation[2]):
                axis = ['x', 'z', 'y']
            else:
                axis = ['z', 'x', 'y']
    else:
        if abs(translation[1])>=abs(translation[2]):
            if abs(translation[0])>=abs(translation[2]):
                axis = ['y', 'x' , 'z']
            else:
                if abs(translation[2])>=abs(translation[1]):
                    axis = ['z', 'y', 'x']
                else:
                    axis = ['y', 'z', 'x']
                    
    return axis



def checkAttr(obj, attr, keyable=True, type='double'):
    """ 
        Checks if the attribute exists on the object. 
        If it doesn't, the attribute will be created.
        :param obj: Object to be evaluated
        :param attr: Attribute to be checked
        :param keyable: = Define if attribute is keyable [True]
        :param type: Type of the attribute ['double']
    """
    if not cmds.attributeQuery(attr, node=obj, exists=True):
        cmds.addAttr(obj, ln=attr, at=type) 
        cmds.setAttr("{0}.{1}".format(obj,attr), k=keyable)


  
def createCurveControl(masterObj, masterAttr, slaveObjs, slaveAttrs, autoConnect=True):
    """ 
        For animation curve control of attributes using a Frame Cache
        Creates a keyframed curve control on the masterObj in order to influence a slaveAttr
        :param masterObj: String of master object
        :param masterAttr: String of master attribute
        :param slaveObjs: List of slave objects
        :param slaveAttrs: List of slave attributes 
        :param autoConnect: Boolean to connect the frame cache's to the slave attributes [True]
    """  
    checkAttr(str(masterObj), str(masterAttr))
        
    #create the keyframed curve
    slavesNum = len(slaveObjs)
    cmds.setKeyframe(masterObj, at=masterAttr, t=1, v=0)
    cmds.setKeyframe(masterObj, at=masterAttr, t=slavesNum, v=0)

    cmds.keyTangent(masterObj, at=masterAttr, wt=True)
    cmds.keyTangent(masterObj, wl=False, at=masterAttr)

    cmds.keyTangent(masterObj, at=masterAttr, e=True, a=True, t=(1,1), oa=50)
    cmds.keyTangent(masterObj, at=masterAttr, e=True, a=True, t=(slavesNum,slavesNum), ia=-50)
    
    #create framecache nodes
    frame=1
    for slaveObj in slaveObjs:
        #set the framecache Node
        splineCacheNode = cmds.createNode("frameCache", n='{0}CacheNode'.format(slaveObj))
        
        #connect the curve to the framecache node
        cmds.connectAttr('{0}.{1}'.format(masterObj, masterAttr), '{0}.stream'.format(splineCacheNode))
        
        cmds.setAttr('{0}.varyTime'.format(splineCacheNode), frame)
        frame += 1
        
        #connect the framecache value to the slaveObj
        if autoConnect == True:
            for slaveAttr in slaveAttrs:
                checkAttr(str(slaveObj), str(slaveAttr))
                cmds.connectAttr('{0}.v'.format(splineCacheNode), '{0}.{1}'.format(slaveObj, slaveAttr), f=True)



def snapRotation(masterObj, slaveObjs):
    """
        DEPRECATED by snap() in coopLib
        Snaps the rotation of the slaves to the master object
        :params masterObj: Master object to snap rotation
        :params slaveObjs: Slave object to snap rotation
    """
    snapPosition(masterObj, slaveObjs, 0, 1)



def snapTranslation(masterObj, slaveObjs):
    """ 
        DEPRECATED by snap() in coopLib
        Snaps the translation of the slaves to the master object
        :params masterObj: Master object to snap translation
        :params slaveObjs: Slave object to snap translation
    """
    snapPosition(masterObj, slaveObjs, 1, 0)    



def snapPosition(masterObj, slaveObjs, translation=1, rotation=1):
    """ 
        DEPRECATED by snap() in coopLib
        Snaps the position of the slaves to the master object
        :params masterObj: Master object to snap position
        :params slaveObjs: Slave object to snap position
        :params translation: Boolean if translation is snapped [True]
        :params rotation: Boolean if translation is snapped [True]
    """
    #slaveObjs has to be a list
    
    #TRANSLATION
    if translation == 1:
        sourceXform = cmds.xform('{0}'.format(masterObj), q=True, worldSpace=True, t=True) 
        
        for slaveObj in slaveObjs:
            cmds.xform('{0}'.format(slaveObj), worldSpace=True, t=(sourceXform[0], sourceXform[1], sourceXform[2]))
    
        print "Translation snapped"
    
    #ROTATION
    if rotation == 1:
        sourceXform = cmds.xform('{0}'.format(masterObj), q=True, worldSpace=True, ro=True) 
        
        print sourceXform
        
        for slaveObj in slaveObjs:
            cmds.xform('{0}'.format(slaveObj), worldSpace=True, ro=(sourceXform[0], sourceXform[1], sourceXform[2]))
        
        if 'cutPlane' in slaveObj:
            cmds.setAttr('{0}.ry'.format(slaveObj), cmds.getAttr('{0}.ry'.format(slaveObj)) + 90)
            
        
        print "Rotation snapped"



def openConstraints():
    """
        Opens constraints mini-shelf
    """
    window = cmds.window('coopConstraints', t="Create constraints", sizeable=False, titleBar=False)
    shelf = cmds.shelfLayout()

    button = cmds.shelfButton(annotation="Parent Constraint: Parent constraint", image1='parentConstraint.png', command="ParentConstraint", sourceType="mel", doubleClickCommand="ParentConstraintOptions" )
    cmds.shelfButton(annotation="Point Constraint: Point constraint", image1="posConstraint.png", command="PointConstraint", sourceType="mel", doubleClickCommand="PointConstraintOptions" )
    cmds.shelfButton(annotation="Orient Constraint: Orient constraint", image1="orientConstraint.png", command="OrientConstraint", sourceType="mel", doubleClickCommand="OrientConstraintOptions" )
    cmds.shelfButton(annotation="Scale Constraint: Scale constraint", image1="scaleConstraint.png", command="ScaleConstraint", sourceType="mel", doubleClickCommand="ScaleConstraintOptions" )
    cmds.shelfButton(annotation="Aim Constraint: Aim constraint", image1="aimConstraint.png", command="AimConstraint", sourceType="mel", doubleClickCommand="AimConstraintOptions" )
    cmds.shelfButton(annotation="Pole Vector Constraint: Pole vector constraint", image1="poleVectorConstraint.png", command="PoleVectorConstraint", sourceType="mel", doubleClickCommand="PoleVectorConstraintOptions" )

    cmds.shelfButton(annotation="Close constraints shelf", image1="coopClose.png", command='maya.utils.executeDeferred("maya.cmds.deleteUI(\'coopConstraints\')")',)

    #resize toolset
    #buttonH = cmds.shelfButton(button, q=True, h=True)
    #buttonW = cmds.shelfButton(button, q=True, w=True)
    #button size is 33 and will always resize accordingly to Maya's internal scaling
    cmds.window(window, edit=True, widthHeight=(33*7, 38*1))

    #show UI
    showConstraintsUI()


def showConstraintsUI():
    """
        Show constraints mini-shelf
    """
    print "Opening constraints shelf"
    if cmds.window('coopConstraints', ex=True):
        cmds.showWindow('coopConstraints')
    else:
        openConstraints()



def shelfBlendShapes():
    """
        Checks the version of Maya and opens whatever is available depending on the version
    """
    if lib.checkAboveVersion(2016):
        mel.eval("ShapeEditor;")
    else:
        mel.eval("CreateBlendShape;")