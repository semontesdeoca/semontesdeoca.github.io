import maya.cmds as cmds

def openCoopRigUI():
    cmds.window("coopRigUI", t="Modular Rigging Toolkit")

    cmds.rowColumnLayout(nc=2, cw =[2, 150])

    cmds.text(" Spine rig")
    cmds.button(label="Spine004", c="Spine004")

    cmds.text("neck set up")
    cmds.button(label="Neck002", c="Neck002")

    cmds.text(" Spine extra")
    cmds.button(label="Spine_extra", c="Spine_extra")

    cmds.text("neck short")
    cmds.button(label="D_Neck_short01", c="D_Neck_short01")

    cmds.text(" Spine extra")
    cmds.button(label="Spine_extra", c="Spine_extra")

    cmds.text("R_ARM  create 4 joint chain")
    cmds.button(label="N_ArmLeft6", c="N_ArmLeft6")

    cmds.text("L_ARM  mirror arm")
    cmds.button(label="N_ArmRight7", c="N_ArmRight7")

    cmds.text("L_HAND_HUMAN default hand 5 finger")
    cmds.button(label="l_hand_start04", c="l_hand_start04")

    cmds.text(" Finishing set up at the origin for human hands 5 fingers")
    cmds.button(label="handsFin04", c="handsFin04")

    cmds.text("ARMS_TWIST")
    cmds.button(label="twist03", c="twist03")

    cmds.text("creates a leg  template joint chain")
    cmds.button(label="D_leg_template", c="D_leg_template")

    cmds.text("complete legs rigging")
    cmds.button(label="D_Legs02", c="D_Legs02")


    cmds.text("quadruped back leg start create 8 joint chain in side view")
    cmds.button(label="quad_start02", c="quad_start02")

    cmds.text("quadruped back leg continue")
    cmds.button(label="quad_cont02", c="quad_cont02")

    cmds.text("quadruped back leg final")
    cmds.button(label="quad_fin01", c="quad_fin01")

    cmds.text("delete  biped legs")
    cmds.button(label="del_leg01", c="del_leg01")

    cmds.text("delete  biped arms with twist inside ")
    cmds.button(label="del_arm01", c="del_arm01")

    cmds.text("TAIL create n_joint chain APP_")
    cmds.button(label="tail", c="tail")

    showCoopRigUI()




def showCoopRigUI():
    """
        Show coop rig UI
    """
    if (cmds.window("coopRigUI", ex=True)):
        cmds.showWindow("coopRigUI")
    else:
        openCoopRigUI()