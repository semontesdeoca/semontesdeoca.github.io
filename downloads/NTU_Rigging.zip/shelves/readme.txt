To maximize compatibility with older versions of Maya, try to keep the shelves to the bare minimum of features.
An example can be seen below

    shelfButton
        -enableCommandRepeat 1
        -enable 1
        -width 34
        -height 34
        -manage 1
        -visible 1
        -preventOverride 0
        -align "center" 
        -label "Add Suffix to selected objects" 
        -labelOffset 0
        -font "tinyBoldLabelFont" 
        -image "suffix.bmp" 
        -image1 "suffix.bmp" 
        -style "iconOnly" 
        -marginWidth 1
        -marginHeight 1
        -command "source js_addSuffixWin;\rjs_addSuffixWin;\r" 
    ;